from django.shortcuts import render,redirect
from .models import Product,CartModel
from django.db.models import Q
from django.contrib.auth.decorators import login_required

# Create your views here.
def home(request):
    print(request.GET)
    if request.user.is_authenticated:
        cartproducts_count = CartModel.objects.filter(host=request.user).count()
    else:
        cartproducts_count=False
    no_match=False
    trend = False
    offer = False
    if 'search' in request.GET:
        search = request.GET['search']
        print(search)
        data = Product.objects.filter(Q(pname__icontains=search) | Q(pdesc__icontains=search))
        if len(data)==0:
            no_match=True
    
    elif 'category' in request.GET:
        category=request.GET['category']
        data = Product.objects.filter(pcategory=category)

    elif 'trending' in request.GET:
        data = Product.objects.filter(trending=True)
        trend = True

    elif 'offer' in request.GET:
        data = Product.objects.filter(offer=True)
        offer = True

    else:  
        data=Product.objects.all()

    #CATERORIES PRESENT IN DB
    a=Product.objects.all()
    category=[]
    for i in a:
        if i.pcategory not in category:
            category+=[i.pcategory]
    print(category)
    return render(request,'home.html',{'data':data,'no_match':no_match,'category':category,'search_bar':True,'trend':trend,'offer':offer,'cartproducts_count':cartproducts_count})

@login_required(login_url='login_')
def cart(request):
    cartproducts_count = CartModel.objects.filter(host=request.user).count()
    print(cartproducts_count)
    tp = 0
    c=0
    cartproducts = CartModel.objects.filter(host=request.user)
    for i in cartproducts:
        tp+=i.totalprice
        c+=i.quantity
    print(tp)
    print(c)
    return render(request,'cart.html',{'cartproducts':cartproducts,'totalprice':tp,'cartproducts_count':cartproducts_count})

@login_required(login_url='login_')
def addtocart(request,id):
    product = Product.objects.get(id=id)
    try:
        cp = CartModel.objects.get(pname = product.pname,host=request.user)
        cp.quantity+=1
        cp.totalprice+=product.price
        cp.save()
    except:
        CartModel.objects.create(
            pname = product.pname,
            price = product.price,
            pcategory = product.pcategory,
            quantity = 1,
            totalprice = product.price,
            host = request.user
        )
    return redirect('cart')

def remove(request,id):
    cartproduct = CartModel.objects.get(id=id)
    cartproduct.delete()
    return redirect('cart')

def increment(request,id):
    cartproduct = CartModel.objects.get(id=id)
    cartproduct.quantity+=1
    cartproduct.totalprice+=cartproduct.price
    cartproduct.save()
    return redirect('cart')

def decrement(request,id):
    cartproduct = CartModel.objects.get(id=id)
    if cartproduct.quantity>1:
        cartproduct.quantity-=1
        cartproduct.totalprice-=cartproduct.price
        cartproduct.save()
    else:
        cartproduct.delete()
    return redirect('cart')