from django.urls import path
from .views import *

urlpatterns = [
    path('register/',register,name='register'),
    path('login_/',login_,name='login_'),
    path('profile/',profile,name='profile'),
    path('logout_/',logout_,name='logout_'),
    path('reset/',reset,name='reset'),
    path('forgot/',forgot,name='forgot'),
    path('update/',update,name='update')
]