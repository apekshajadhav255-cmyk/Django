from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from base.models import CartModel

# Create your views here.
def register(request):
    if request.method=='POST':
        try:
            u = User.objects.get(username=request.POST['username'])
            return render(request,'register.html',{'error':'Username already exists'})
        except:
            u = User.objects.create(
                first_name = request.POST['fname'],
                last_name = request.POST['lname'],
                email = request.POST['email'],
                username = request.POST['username']
            )
            u.set_password(request.POST['password'])
            u.save()
            return redirect('login_')
    return render(request,'register.html')

def login_(request):
    if request.method == 'POST':
        u = authenticate(username=request.POST['username'],password=request.POST['password'])
        if u:
            login(request,u)
            return redirect('home')
        else:
            return render(request,'login_.html',{'error':'Invalid username or password'})
    return render(request,'login_.html')

@login_required(login_url='login_')
def profile(request):
    cartproducts_count = CartModel.objects.filter(host=request.user).count()
    return render(request,'profile.html',{'cartproducts_count':cartproducts_count})

@login_required(login_url='login_')
def logout_(request):
    logout(request)
    return redirect('login_')

@login_required(login_url='login_')
def reset(request):
    if request.method == 'POST':
        if 'old_pass' in request.POST:
            u = authenticate(username=request.user.username,password=request.POST['old_pass'])
            print(u)
            if u:
                return render(request,'reset.html',{'new':True})
            else:
                return render(request,'reset.html',{'error':'Incorrect Old Password'})
        if 'new_pass' in request.POST:
            new = request.POST['new_pass']
            if request.user.check_password(new):
                return render(request,'reset.html',{'error':'New password should not be same as old password','new':True})
            request.user.set_password(new)
            request.user.save()
            return redirect('logout_')
    return render(request,'reset.html')

def forgot(request):
    return render(request,'forgot.html')

@login_required(login_url='login_')
def update(request):
    data = request.user #user object instance
    if request.method == 'POST':
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        data.first_name = fname
        data.last_name = lname
        data.email = email
        data.save()
        return redirect('profile')
    return render(request,'update.html')

'''
Write the logic for
1. register
2. login_
3. profile
4. logout_
5. reset password
6. forgot password
'''